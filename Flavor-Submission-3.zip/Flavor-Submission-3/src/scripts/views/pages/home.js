import RestauranAppsSource from "../../data/restaurantapps-source";
import { createRestoItemTemplate } from "../template/template-creator";
// eslint-disable-next-line import/extensions
import "../../component/testimonial.js";

const home = {
  async render() {
    return `
      <div id='loading' class='loading'>Loading...</div>
      <flavor-hero></flavor-hero>
      <section class='content'>
        <h1 class='judul'>Explore Restaurant</h1>
        <div class='card_list' id='list'></div>
      </section>
      <flavor-testi></flavor-testi>
    `;
  },

  async afterRender() {
    const loadingElement = document.querySelector("#loading");
    const restaurantsElement = document.querySelector("#list");

    try {
      // Menampilkan loading
      loadingElement.style.display = "block";
      // Mengambil data dari server
      const restaurants = await RestauranAppsSource.home();
      // Menghilangkan loading dan menampilkan konten
      loadingElement.style.display = "none";
      restaurants.forEach((restaurant) => {
        restaurantsElement.innerHTML += createRestoItemTemplate(restaurant);
      });
    } catch (error) {
      // Menampilkan pesan error jika terjadi kesalahan
      loadingElement.innerHTML = "Failed to load data.";
      console.error(error);
    }
  },
};

export default home;
